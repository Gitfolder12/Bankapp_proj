create or replace PROCEDURE                  gui.pr_log_action (
    p_owner        IN VARCHAR2,
    p_base_table   IN VARCHAR2,
    p_object_name  IN VARCHAR2,
    p_object_type  IN VARCHAR2,
    p_status       IN VARCHAR2,
    p_error_msg    IN VARCHAR2 DEFAULT NULL
) AUTHID CURRENT_USER
IS
BEGIN
    -- Insert log row
    -----------------------------------------------------------------
    INSERT INTO gui.hwm_log (
        owner,
        base_table,
        object_name,
        object_type,
        status,
        error_msg
    ) VALUES (
        p_owner,
        p_base_table,
        p_object_name,
        p_object_type,
        p_status,
        p_error_msg
    );

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('pr_log_action failed: ' || SQLERRM );
END ;
/