create or replace PROCEDURE     gui.pr_hwm_move_tables (
    p_schema       IN VARCHAR2,
    p_table_tbs    IN VARCHAR2,
    p_index_tbs    IN VARCHAR2,
    p_max_runtime  IN NUMBER DEFAULT 60,
    p_table_name   IN VARCHAR2 DEFAULT NULL
)
AUTHID CURRENT_USER
IS
    -- Runtime control
    v_start_time   INTEGER := DBMS_UTILITY.GET_TIME;

    -- Logging variables
    v_table_name   VARCHAR2(128);
    v_object_name  VARCHAR2(128);
    v_object_type  VARCHAR2(20);
    v_status       VARCHAR2(20);
    v_error_msg    VARCHAR2(4000);


    -- Runtime window check
    FUNCTION runtime_exceeded RETURN BOOLEAN IS
    BEGIN
        RETURN (DBMS_UTILITY.GET_TIME - v_start_time)/100 > (p_max_runtime * 60);
    END;

    -- Logging wrapper
    PROCEDURE log_result IS
    BEGIN
        gui.pr_log_action(
            p_owner       => p_schema,
            p_base_table  => v_table_name,
            p_object_name => v_object_name,
            p_object_type => v_object_type,
            p_status      => v_status,
            p_error_msg   => v_error_msg
        );
    END;


BEGIN
    -- Loop over NON-PARTITIONED TABLES
    -------------------------------------------------------------------------
    FOR tb1 IN (
        SELECT t.table_name
        FROM   dba_tables t
        WHERE  t.owner       = p_schema
          AND  t.partitioned = 'NO'
          AND  t.temporary   = 'N'
          and  t.table_name <> 'HWM_LOG'
          AND  (p_table_name IS NULL OR t.table_name = UPPER(p_table_name))
          AND  NOT EXISTS (
                    SELECT 1
                    FROM   fdr.hwm_log l
                    WHERE  l.owner       = p_schema
                      AND  l.base_table  = t.table_name
                      AND  l.object_type = 'TABLE'
                      AND  l.status      = 'SUCCESS'
               )
          AND  NOT EXISTS (
                       SELECT 1
                       FROM   dba_tab_columns c
                       WHERE  c.owner      = t.owner
                       AND    c.table_name = t.table_name
                       AND    c.data_type  = 'LONG'
                   )
    )
    LOOP
          v_table_name := tb1.table_name;

          -- Stop if runtime exceeded
          exit when runtime_exceeded; 

          --set context failure(before move)
          v_object_name := v_table_name;
          v_object_type := 'TABLE';

            -- MOVE TABLE 
            -------------------------------------------------------------------
            EXECUTE IMMEDIATE 
                ' ALTER TABLE '
                ||p_schema
                ||'.'
                ||v_table_name
                ||' MOVE TABLESPACE '
                ||p_table_tbs
                ||' UPDATE GLOBAL INDEXES ';

            -- MOVE LOB SEGMENTS
            -------------------------------------------------------------------
            FOR lob_rec IN (
                SELECT column_name
                FROM   dba_lobs
                WHERE  owner = p_schema
                  AND  table_name = v_table_name
            )
            LOOP
                EXECUTE IMMEDIATE
                    ' ALTER TABLE '
                    ||p_schema
                    ||'.'
                    ||v_table_name
                    ||' MOVE LOB ('||lob_rec.column_name||') STORE AS (TABLESPACE '
                    ||p_table_tbs||')';
            END LOOP;

            -- REBUILD UNUSABLE INDEXES
            -------------------------------------------------------------------
            FOR ix IN (
                SELECT i.index_name,
                           i.tablespace_name
                    FROM   dba_indexes i
                    JOIN   dba_tables  t
                           ON t.owner      = i.owner
                          AND t.table_name = i.table_name
                    WHERE  i.owner       = p_schema
                      AND  i.table_name  = v_table_name
                      AND  i.partitioned = 'NO'
                      AND  t.temporary   = 'N' 
                      AND  i.index_type  not in ('LOB','DOMAIN')
                      AND (i.status      = 'UNUSABLE' OR i.tablespace_name IN (
                               p_schema||'_DATA',
                               p_schema||'_DATA_IDX' )   
                               )
            )
            LOOP
                    EXECUTE IMMEDIATE
                        ' ALTER INDEX '
                        ||p_schema
                        ||'.'
                        ||ix.index_name
                        ||' REBUILD ONLINE TABLESPACE '
                        || p_index_tbs ;

            END LOOP;
             
             --unlock tables
             DBMS_STATS.UNLOCK_TABLE_STATS(p_schema,v_table_name);
             
            --gather Stats
             DBMS_STATS.GATHER_TABLE_STATS(
                ownname          => p_schema,
                tabname          => v_table_name,
                cascade          => TRUE
            );

            -- LOG SUCCESS
            -------------------------------------------------------------------
            v_status      := 'SUCCESS';
            v_error_msg   := NULL;
            log_result;

    END LOOP;

EXCEPTION WHEN OTHERS THEN
            v_status      := 'FAILED';
            v_error_msg   := SQLERRM || ' | ' || DBMS_UTILITY.format_error_backtrace;
            log_result;

END ;
/