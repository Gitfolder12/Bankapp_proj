--Step 1. SET DEFAULT ATTRIBUTES (VERY IMPORTANT)

-- Normal partition tables
DECLARE
  v_new_tbs VARCHAR2(30) := 'FDR_DATA_MOVE';
  v_schema  VARCHAR2(30) := 'GUI';
BEGIN
  FOR t IN (
    SELECT TABLE_NAME
    FROM   DBA_PART_TABLES
    WHERE  OWNER                = v_schema
    and    table_name not like '%BIN$%'
    AND    SUBPARTITIONING_TYPE = 'NONE'
    ORDER  BY TABLE_NAME
  )
  LOOP
    BEGIN
      EXECUTE IMMEDIATE ' ALTER TABLE ' 
                        || v_schema 
                        || '.' 
                        || t.TABLE_NAME 
                        ||' MODIFY DEFAULT ATTRIBUTES TABLESPACE ' 
                        || v_new_tbs;
    EXCEPTION
      WHEN OTHERS THEN NULL;

    END;
  END LOOP;
END;
/


---Composite partition tables
DECLARE
  v_new_tbs VARCHAR2(30) := 'FDR_DATA_MOVE';
  v_schema  VARCHAR2(30) := 'GUI';
BEGIN
  FOR rec IN (
    SELECT pt.TABLE_NAME,
           p.PARTITION_NAME
    FROM   DBA_PART_TABLES pt
    JOIN   DBA_TAB_PARTITIONS p
           ON pt.OWNER = p.TABLE_OWNER
          AND pt.TABLE_NAME = p.TABLE_NAME
    WHERE  pt.OWNER = v_schema
    AND    pt.SUBPARTITIONING_TYPE != 'NONE'   -- composite only
    AND    pt.TABLE_NAME NOT LIKE '%BIN$%'
    ORDER  BY pt.TABLE_NAME
  )
  LOOP

    BEGIN
      EXECUTE IMMEDIATE 'ALTER TABLE ' 
                        || v_schema 
                        || '.' 
                        || rec.TABLE_NAME 
                        ||' MODIFY DEFAULT ATTRIBUTES TABLESPACE ' 
                        || v_new_tbs;

      EXECUTE IMMEDIATE  'ALTER TABLE ' 
                        || v_schema 
                        || '.' 
                        || rec.TABLE_NAME 
                        ||' MODIFY DEFAULT ATTRIBUTES FOR PARTITION ' 
                        || rec.PARTITION_NAME 
                        ||' TABLESPACE ' 
                        || v_new_tbs;

    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

  END LOOP;
END;
/


